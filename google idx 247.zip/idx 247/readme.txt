cloudflared tunnel --url http://localhost:8080

python3 connector.py


wget https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64 -O cloudflared


chmod +x cloudflared


./cloudflared tunnel --url http://localhost:8080




source .venv/bin/activate