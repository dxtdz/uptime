PING_INTERVAL = 5      # ping every 5 seconds
TIMEOUT = 2            # wait max 2 sec per request
MAX_FAILS = 5

DISCORD_WEBHOOK = "https://discord.com/api/webhooks/1454409613372948572/FzKdMaqyACuf5LloNgC42N-WJry20qHaSBBx5ATwtTa23yfGy5ufZhOeTYd85CDrpNeM"

DASHBOARD_HOST = "0.0.0.0"
DASHBOARD_PORT = 9000
